import closest from './closest';

export default closest;
