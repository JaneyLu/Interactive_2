import TouchSensor from './TouchSensor';

export default TouchSensor;
