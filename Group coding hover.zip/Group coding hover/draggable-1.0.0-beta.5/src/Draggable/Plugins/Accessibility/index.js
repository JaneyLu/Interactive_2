import Accessibility from './Accessibility';

export default Accessibility;
