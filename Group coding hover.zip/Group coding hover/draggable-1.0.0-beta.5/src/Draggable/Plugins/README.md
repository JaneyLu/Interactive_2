## Draggable plugins

These plugins are included by draggable by default

- [Accessibility](Accessibility)
- [Mirror](Mirror)
- [Scrollable](Scrollable)
- [Announcement](Announcement)
